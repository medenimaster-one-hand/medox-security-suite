#!/bin/bash

show_shield_menu() {
    clear
    echo -e "\e[1;32m========================================================\e[0m"
    echo -e "\e[1;32m               WHITEHAT SHIELD FIREWALL MENU            \e[0m"
    echo -e "\e[1;32m========================================================\e[0m"
    echo -e "1) View current firewall status (UFW)"
    echo -e "2) Activate GOLDEN RULE + iptables deep defense layers"
    echo -e "3) Restrict specific network port (e.g., 8080 or 23)"
    echo -e "4) Exit Subsystem"
    echo -e "\e[1;32m========================================================\e[0m"
}

# Ovde ide tvoja glavna logika za ufw i iptables izvršavanje
while true; do
    show_shield_menu
    read -p "Select an option (1-4): " shield_option
    case $shield_option in
        1)
            echo -e "\n[+] Checking UFW firewall status..."
            sudo ufw status verbose
            read -p "Press [Enter] to continue..."
            ;;
        2)
            echo -e "\n[+] Activating Golden Rule + Deep Kernel Defense..."
            # Tvoja postojeca pravila za ufw i iptables idu ovde
            sudo ufw default deny incoming
            sudo ufw default allow outgoing
            sudo ufw enable
            echo -e "\e[1;32m[V] Deep firewall protection activated successfully!\e[0m"
            read -p "Press [Enter] to continue..."
            ;;
        3)
            echo -e "\n"
            read -p "Enter the port number you want to LOCK: " target_port
            if [ -z "$target_port" ]; then
                echo -e "\e[1;31m[-] Invalid port entry!\e[0m"
            else
                sudo ufw deny $target_port
                echo -e "\e[1;31m[-] Port $target_port has been permanently locked in UFW/iptables!\e[0m"
            fi
            read -p "Press [Enter] to continue..."
            ;;
        4)
            echo -e "\n[+] Terminating SHIELD module. Returning to core suite..."
            exit 0
            ;;
        *)
            echo -e "\n\e[1;31mInvalid option!\e[0m Please select between 1 and 4."
            sleep 2
            ;;
    esac
done
